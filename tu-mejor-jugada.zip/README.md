# Tu Mejor Jugada — juego educativo

Tres desafíos para estudiantes secundarios de Catamarca:

1. **Cazá el mito:** preguntas sobre mitos y riesgos de las apuestas online.
2. **Elegí la jugada:** decisiones ante enlaces, presión de pares y señales de alerta.
3. **Creá tu spot:** generador de un guion de prevención de 45 segundos, que se puede copiar o descargar.

El juego suma hasta 100 puntos, da explicaciones fundamentadas después de cada respuesta, funciona en celulares y no solicita datos personales. **No contiene enlaces de inscripción ni fechas de cierre**. El cierre motiva a crear un video y participar con el curso.

## Publicar gratis en GitHub Pages

1. En GitHub, crear un repositorio **público** llamado `tu-mejor-jugada`.
2. Cargar **el contenido de esta carpeta** en la raíz del repositorio (`index.html`, `app.js`, `styles.css` y `assets/`), no el ZIP como un archivo individual.
3. Ir a **Settings → Pages → Build and deployment**.
4. Seleccionar **Deploy from a branch**, la rama **main** y la carpeta **/(root)**. Guardar.
5. El enlace tendrá este formato: `https://USUARIO.github.io/tu-mejor-jugada/`.

No es necesario instalar dependencias ni crear una base de datos. Para probarlo localmente, abrir `index.html` o servir la carpeta con un servidor HTTP.

## Logos

Los archivos en `assets/logo-caja.svg` y `assets/logo-tu-mejor-jugada.svg` son **versiones tipográficas de muestra**, no archivos oficiales. Para publicar como pieza institucional, reemplazarlos por los logos originales autorizados, conservando esos nombres de archivo (o ajustando las rutas en `index.html`).

## Fundamentación de las respuestas

Las devoluciones pedagógicas se basan en material preventivo de UNICEF Argentina, la Organización Mundial de la Salud y el Gobierno nacional. Cada pregunta incluye una referencia que lleva a una fuente educativa, no a la inscripción.

- [UNICEF Argentina: apuestas online](https://www.unicef.org/argentina/apuestas-online)
- [UNICEF Argentina: apuestas online y salud mental adolescente](https://www.unicef.org/argentina/apuestas-online-salud-mental)
- [Argentina.gob.ar: apuestas online y juego problemático](https://www.argentina.gob.ar/capital-humano/familia/bienestar-emocional/somos-familia/apuestas-online-y-juego-problematico)
- [OMS: juegos de azar y apuestas](https://www.who.int/es/news-room/fact-sheets/detail/gambling)

## Aspectos de privacidad y accesibilidad

- Sin cookies, registro, almacenamiento ni seguimiento de estudiantes.
- Respuestas operables con teclado y mensajes de devolución accesibles.
- Sin temporizador ni penalización por tardar.
- Respeta la preferencia del dispositivo de reducir animaciones.
